void guardar_nodos_ordenados(char* filename);
void bubblesort();
void mergesort();
void quicksort();
void selectionsort();
void insertionsort();
void swap(int *x, int *y);