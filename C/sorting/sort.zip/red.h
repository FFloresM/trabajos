typedef struct $
{
	int id;
	int *link_ids;
	int links;
}Nodo;

void leer_archivo(char* filename);