#include "prueba.h"

int main(){
    leer_archivo("MOCK_DATA.txt");
    ordenar();
    imprimir_personas();
    imprimir(0);
}
