
public interface Funciones {
    
}