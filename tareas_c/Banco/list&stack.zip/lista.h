#include <stdio.h>

struct nodo
{
	void value;
	struct nodoLista* sig;
}Lista;

void crear_lista();
void agregar_elemento_lista();
void remover_elemento_lista();

